#include "UI.h"

#include <iostream>
#include <iomanip>
#include <exception>

void UI::checkPositive(double t_input) {
	bad_cast exep = bad_cast();
	if (t_input <= 0 || cin.fail()) throw exep;
}

void UI::prompt(Account& t_account){

	//Storage variables for user input into account
	double principle = -1;
	double monthlyDeposit = -1;
	double annualInterest = -1;
	int numYears = -1;

	//Print header
	cout << setw(40) << setfill('*') << "" << endl;
	cout << "************** Data Input **************" << endl;

	//Prompt for principle
	cout << setw(0) << "Initial Investment Amount: $";
	cin >> principle;
	checkPositive(principle);

	//prompt for monthly deposit
	cout << "Monthly Deposit: $";
	cin >> monthlyDeposit;
	checkPositive(monthlyDeposit);
	
	//prompt for annual interest
	cout << "Annual Interest: %";
	cin >> annualInterest;
	checkPositive(annualInterest);

	//prompt for number of years
	cout << "Number of years: ";
	cin >> numYears;
	checkPositive(numYears);

	//Print footer
	cout << setw(40) << setfill('*') << "" << endl;

	//Generate the account
	t_account = Account(principle, monthlyDeposit, annualInterest, numYears);

	return;
}

void UI::output(Account& account){

	//Print header
	cout << setw(60) << setfill('-') << "" << endl;
	cout << "  Balance and Interest Without Additional Monthly Deposits  " << endl;
	cout << setw(60) << setfill('-') << "" << endl;
	cout << setw(0) << "  Year     " << "Year End Balance      " << "Year End Earned Interest   " << endl;
	cout << setw(60) << setfill('-') << "" << endl;

	//print info for each year for no deposit projection
	for (int year = 0; year < account.getYears(); year++) {
		cout << setprecision(2) << fixed << setfill(' ');
		cout << "  ";
		cout << setw(4) << left << year + 1;
		cout << "     $";
		cout << setw(15) << left << account.getBalanceNoDeposit(year);
		cout << "      $";
		cout << setw(15) << left << account.getInterestNoDeposits(year) << endl;
	}

	//Print footer
	cout << setw(60) << setfill('-') << "" << endl;
	cout << endl;

	//print header
	cout << setw(60) << setfill('-') << "" << endl;
	cout << "    Balance and Interest With Additional Monthly Deposits   " << endl;
	cout << setw(60) << setfill('-') << "" << endl;
	cout << setw(0) << "  Year     " << "Year End Balance      " << "Year End Earned Interest   " << endl;
	cout << setw(60) << setfill('-') << "" << endl;

	//print info for each year for deposit projection
	for (int year = 0; year < account.getYears(); year++) {
		cout << setprecision(2) << fixed << setfill(' ');
		cout << "  ";
		cout << setw(4) << left << year + 1;
		cout << "     $";
		cout << setw(15) << left << account.getBalanceWithDeposit(year);
		cout << "      $";
		cout << setw(15) << left << account.getInterestWithDeposits(year) << endl;
	}

	//Print footer
	cout << setw(60) << setfill('-') << "" << endl;
	cout << endl << endl;
}

bool UI::checkQuit() {

	string input = ""; //holds user input temporarily

	cout << "Enter \"q\" to quit or any other letter to continue: ";
	
	cin >> input;

	if (input == "q") return true; //quit
	else return false; //continue
}
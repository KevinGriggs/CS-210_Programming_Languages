#include "Account.h"

//initializes the 4 core variables
Account::Account(double t_principle, double t_monthlyDeposit, double t_interestRate, int t_years) :
	m_principle{ t_principle },
	m_monthlyDeposit{ t_monthlyDeposit },
	m_interestRate{ t_interestRate },
	m_years{ t_years }{

	//resize the vectors to m_years
	m_balanceNoDeposit.resize(m_years);
	m_balanceDeposits.resize(m_years);
	m_interestNoDeposit.resize(m_years);
	m_interestDeposits.resize(m_years);


	calculateBalance(); //calculates the balance after contstruction is completed
}

void Account::calculateBalance() {
	calculateYearBalance(m_principle, m_principle, 0); //Calculates the first year's balance

	//Calculate the balance for the remaining years
	for (int year = 1; year < m_years; year++) {
		calculateYearBalance(m_balanceNoDeposit.at(year - 1), m_balanceDeposits.at(year - 1), year); //use last years balance as the starting value for this year
	}

}

double Account::calculateInterestEarned(double t_balance, bool t_withDeposit) const{
	return (t_balance + m_monthlyDeposit * t_withDeposit) * (m_interestRate / 100 / 12); //Uses boolean mathematics to account for t_withDeposit
}

void Account::calculateYearBalance(double t_startingBalanceNoDeposit, double t_startingBalanceDeposits, int t_year) {

	//Holds the various values calculated for the year during calculation
	double yearBalanceNoDeposits = t_startingBalanceNoDeposit;
	double yearBalanceDeposits = t_startingBalanceDeposits;
	double yearInterestNoDeposits = 0;
	double yearInterestDeposits = 0;

	//For each month
	for (int month = 0; month < 12; month++) {

		//Add the month's interest earned to yearly totals
		yearInterestNoDeposits += calculateInterestEarned(yearBalanceNoDeposits, false);
		yearBalanceNoDeposits += calculateInterestEarned(yearBalanceNoDeposits, false);
		yearInterestDeposits += calculateInterestEarned(yearBalanceDeposits, true);
		yearBalanceDeposits += calculateInterestEarned(yearBalanceDeposits, true);

		yearBalanceDeposits += m_monthlyDeposit; //Add the monthly deposit to the deposit balance (already accounted for in interest calculations)

	}
	//Set the values for the year in the account vector
	m_balanceNoDeposit.at(t_year) = yearBalanceNoDeposits;
	m_balanceDeposits.at(t_year) = yearBalanceDeposits;
	m_interestNoDeposit.at(t_year) = yearInterestNoDeposits;
	m_interestDeposits.at(t_year) = yearInterestDeposits;

}
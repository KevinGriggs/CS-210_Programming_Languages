/*
* This class describes a bank account with a principle, interest rate (compounded monthly), monthly deposit amount, and number of years active
* and calculates the total balance and interest earned of the account in cases of monthly deposits and no monthly depostits for each year active.
*/

#ifndef BANKAPP_HEADERFILES_ACCOUNT_H_
#define BANKAPP_HEADERFILES_ACCOUNT_H_

#include <vector>

using namespace std;

class Account {

public:
	Account() {};
	Account(double t_principle, double t_monthlyDeposit, double t_interestRate, int t_years);

	//Getters (used by UI)
	int getYears() { return m_years; }
	double getBalanceNoDeposit(int t_year) const { return m_balanceNoDeposit.at(t_year); }
	double getBalanceWithDeposit(int t_year) const { return m_balanceDeposits.at(t_year); }
	double getInterestNoDeposits(int t_year) const { return m_interestNoDeposit.at(t_year); }
	double getInterestWithDeposits(int t_year) const { return m_interestDeposits.at(t_year); }

	//Calculates the balance and interest earned of the account for every year in both scenarios 
	void calculateBalance();

private:

	/*Private Variables*/

	double m_principle = 0.f; //The account's opening amount
	double m_monthlyDeposit = 0.f; //The amount the user will deposit monthly
	double m_interestRate = 0.f; //The interest rate of the account
	int m_years = 0; //The years the account has been active

	//Vectors storing the total balance and interest earned for each year
	vector<double> m_balanceNoDeposit;
	vector<double> m_balanceDeposits;
	vector<double> m_interestNoDeposit;
	vector<double> m_interestDeposits;

	/*Private Functions*/

	//Calculates the interest earned in one month based on a starting balance
	double calculateInterestEarned(double t_balance, bool t_withDeposit) const;

	//Calculates the year's balance and interest based on starting balance
	void calculateYearBalance(double t_startingBalanceNoDeposit, double t_startingBalanceDeposits, int t_year);

};

#endif // !BANKAPP_HEADERFILES_ACCOUNT_H_


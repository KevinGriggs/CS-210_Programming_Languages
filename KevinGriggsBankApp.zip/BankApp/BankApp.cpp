/*
* Author: Kevin Griggs
* Date: 6/8/2021
* 
* Files: BankApp.cpp, Account.h, Account.cpp, UI.h, UI.cpp
*
* This program is a calculator for compound interest gained on a bank account.
* The program prompts the user for the principle, a monthy deposit, the interest rate, and the number of years since the account was opened.
* The program then calculates the interest earned and total balance year to year in the scenario that no additional deposits are made
* and in the scenario that the monthly deposit is made and outputs those values.
*/

#include "Account.h"
#include "UI.h"
#include <iostream>
#include <cstdio>

int main() {
	
	bool toQuit = false; //holds whether or not to end the main loop and quit the program

	//While the user does not wish to quit
	while(!toQuit) {

		//The account object
		Account account;

		try {
			UI::prompt(account); //prompt the user for input
		}
		catch (bad_cast exep) { //if input is invalid, warn the user and reprompt
			cout << endl << "That input was invalid, please try again." << endl << endl;
			cin.clear();
			cin.ignore(500, '\n'); //See this article on the method (since there isn't a command that works for all systems)https://stackoverflow.com/questions/257091/how-do-i-flush-the-cin-buffer
			continue;
		}

		cout << endl;

		UI::output(account); //output the balance information

		toQuit = UI::checkQuit(); //prompt the user on whether or not to quit

	}

	return 0;
}
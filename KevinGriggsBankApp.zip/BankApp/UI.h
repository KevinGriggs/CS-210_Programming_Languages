/*
* This class defines a set of functions for geting user input
* for the gathering of account info and program controls (see checkQuit() for the latter)
* and functions for the output and formatting of account info.
*/

#ifndef BANKAPP_HEADERFILES_UI_H_
#define BANKAPP_HEADERFILES_UI_H_
#include "Account.h"
#include <string>

using namespace std;

static class UI {
public:

	//Prompts the user for data entry and collects information
	static void prompt(Account& t_acccount);

	//Prints the account information
	static void output(Account& t_account);

	//prompts the user to see if they wish to enter another account
	static bool checkQuit();

private:

	//checks input to see if its a positive number
	static void checkPositive(double t_input);

};

#endif // !BANKAPP_HEADERFILES_UI_H_

